#include <iostream>
#include <fstream>
#include <iomanip>
#include <vector>
#include "TH1.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TProfile.h"
#include "TTree.h"
#include "TFile.h"
#include "TStyle.h"
#include "TMath.h"
#include "TMinuit.h"
#include "TObject.h"
#include "TPostScript.h"
#include <TRandom3.h>
#include "CLHEP/Vector/ThreeVector.h"
#include "CLHEP/Vector/LorentzVector.h"
#include "CLHEP/Matrix/Matrix.h"

#define DELTARAY //Removal of hits from delta ray (fill_digipos_array)
//#define SMEARING // Smeaing of signal or not (put by hand in  fill_digipos_array)

using namespace std;
using namespace CLHEP;

struct fourparam{
  float hit1;
  float hit2;
  float slope;
  float inter;
};

vector<fourparam> allmmcc;
vector<fourparam> tmpallmmcc;
vector<Hep3Vector> fit_input3v;

vector<fourparam> allmmcc_rphi;
vector<fourparam> tmpallmmcc_rphi;
vector<Hep3Vector> fit_input3v_rphi;

const double pival = acos(-1.0);
const double twopi = 2*pival;
const double pibytwo = pival/2.;
const double pibyfour = pival/4.;
const double radtodeg = 180./pival;
const int nNoiseHit=0; //Constant noise hit in the detector;
const int nsilayer=13;
const int nmnhit=3; //Minimum number of layers for the track fit

double sirad[nsilayer]={0.029, 0.068, 0.109, 0.160, 0.220, 0.290, 0.370, 0.450, 0.520, 0.590, 0.660, 0.730, 0.800}; 
double momconv = 0.299792*3.8;
double extrad=0.0289; //0.025; //2.0e-4; //0.002; //0.025;

//Without any smearing and noise
double phireso2fact = 2.5e-9/12.0;
double zreso2fact = 4.0e-8/12.0;

//Fill position from true sim hit information
void fill_digi_from_sim(int nsimhit, int* pdgid, float* simvx, float* simvy, float* simvz, float* simtime, vector<Hep3Vector>& hitpos);

//convert digisignal to hit position (3vector) including inefficinecy and noise 
void fill_digipos_array(int nhit, unsigned int* detid, int* pdgid, float* simenr, float* simtime, vector<Hep3Vector>& hitpos);

//Simple straight line fit to get theta and z
void straight_line_fit(vector<Hep3Vector> finder, double* par, double* parerr);

//Move track from one point to a nearest point(x,y)
void track_move_pt_align( double* b, double* tin, double q, double* x, double* tout, double& dl); 
// Extrapolation of track to next layer including energyloss
bool GetPrediction(double radin, double* StateVector, double* Prediction, int il, double*  Q_k_minus, int ix); 

void MultipleScattering(double* StateVector, double* error, int il) {;}


double sfdph(double phi1, double phi2) {
  double dphi = phi2 - phi1;
  if (dphi > M_PI) { dphi = 2*M_PI - dphi;}
  if (dphi < -M_PI){ dphi = 2*M_PI + dphi;}
  return dphi;
}

TRandom3* gRandom3 = new TRandom3();

int main() {

  //Change the radius of silicon layer to incorporate the thickness 300/2 micron = 0.00015m
  for (int ij=0; ij<nsilayer; ij++) {
    sirad[ij] +=0.00015;
  }

  char datafile[100];
  unsigned   irun;                // Run number of these events
  unsigned   ievt;                //Event number
  unsigned   ngent;
  float	ievt_wt;
  //
  unsigned   ntrkt;
  const unsigned int ngenmx=50;
  int   pidin[ngenmx]; 	  //PID of incident particle
  float momin[ngenmx]; 	  //Energy of incident particle
  float thein[ngenmx];	  //Initial polar angle of incident particle
  float phiin[ngenmx];     //Initial azimuthal angle of incident particle 
  float posxin[ngenmx];	  //Initial X-position
  float posyin[ngenmx];     //Initial Y-position
  float poszin[ngenmx];     //Initial Z-position

  unsigned int nsimhtTk;
  const unsigned int nsimhtmxTk=2000;   //Number of silicon hits
  unsigned int detidTk[nsimhtmxTk];     //ID of silicon hits (used fill_digipos_array to get (x,y,z)

  float simtimeTk[nsimhtmxTk];    // Time of hits in ns (not used)
  float simenrTk[nsimhtmxTk];    // Energy deposite in keV of hits (not used)

  int   simpdgidTk[nsimhtmxTk];  // PDGID, which produce this hit (not used, but can use to clean hit from delta-ray)
  float simvxTk[nsimhtmxTk];    //exact position (x in mm) of the partcle tajectory, which produce this hit
                                //(can check ideal case of trajectories only with multiple scattering)
  float simvyTk[nsimhtmxTk];    //exact position (y in mm) of the partcle tajectory, which produce this hit
  float simvzTk[nsimhtmxTk];    //exact position (z in mm) of the partcle tajectory, which produce this hit
  float simpxTk[nsimhtmxTk];    //px (in MeV) of the partcle tajectory, which produce this hit
  float simpyTk[nsimhtmxTk];    //py (in MeV) of the partcle tajectory, which produce this hit
  float simpzTk[nsimhtmxTk];    //pz (in MeV) of the partcle tajectory, which produce this hit

  float simloctheTk[nsimhtmxTk]; //Polar angle in the local co-ordinate in the sensor (not used)
  float simlocphiTk[nsimhtmxTk]; //Azimuthal angle in the local co-ordinate in the sensor (not used)

  vector<Hep3Vector> digihitpos;

  TFile* fileOut = new TFile("output_skeleton.root", "recreate");
  
  TTree* Tout = new TTree("T2", "test");

  Tout->Branch("irun",&irun,"irun/i");
  Tout->Branch("ievt",&ievt,"ievt/i");
  
  ifstream file_db;
  file_db.open("skeleton_track.log");
  while(!(file_db.eof())) {
    int nentrymx=-1;
    
    file_db >> datafile>>nentrymx;
    if (strstr(datafile,"#")) continue;

    cout <<"datafile = "<<datafile<<endl;
    
    if(file_db.eof()) break; 
      
    TFile* fileIn = new TFile(datafile, "read");
    TTree *Tin = (TTree*)fileIn->Get("T1");

    Tin->SetBranchAddress("irun",&irun);
    Tin->SetBranchAddress("ievt",&ievt);
    
    Tin->SetBranchAddress("ngent",&ngent);
    Tin->SetBranchAddress("pidin",pidin);
    Tin->SetBranchAddress("ievt_wt",&ievt_wt);
    Tin->SetBranchAddress("momin",momin);
    Tin->SetBranchAddress("thein",thein);
    Tin->SetBranchAddress("phiin",phiin);
    Tin->SetBranchAddress("posxin",posxin);
    Tin->SetBranchAddress("posyin",posyin);
    Tin->SetBranchAddress("poszin",poszin);

    //SImulated output of tracker
    Tin->SetBranchAddress("nsimhtTk", &nsimhtTk);
    Tin->SetBranchAddress("detidTk", detidTk);
    Tin->SetBranchAddress("simpdgidTk", simpdgidTk);
    Tin->SetBranchAddress("simtimeTk", simtimeTk);
    Tin->SetBranchAddress("simenrTk", simenrTk);
    Tin->SetBranchAddress("simvxTk", simvxTk);
    Tin->SetBranchAddress("simvyTk", simvyTk);
    Tin->SetBranchAddress("simvzTk", simvzTk);
    Tin->SetBranchAddress("simpxTk", simpxTk);
    Tin->SetBranchAddress("simpyTk", simpyTk);
    Tin->SetBranchAddress("simpzTk", simpzTk);
    
    int nentries = Tin->GetEntries();
    cout <<"nentr "<< datafile<<" "<<nentries<<endl;;
    int ievhst=0;
    
    for (int iev=0; iev<min(nentries, nentrymx); iev++) {
      fileIn->cd();
      Tin->GetEntry(iev); //+66286); //+280717); //+96427); //(+1853); // (1715);
      cout<<"Starting evet #============== "<<ievt<<" "<<momin[0]<<" "<<momin[0]*sin(thein[0])<<" "<<thein[0]<<" "<<phiin[0]<<endl;

      
      fileOut->cd();

      digihitpos.clear();

      if (simenrTk==0) continue;

      // Use exactly the sim hit position to test the ideal algorithm
      fill_digi_from_sim(nsimhtTk,  simpdgidTk, simvxTk, simvyTk, simvzTk, simtimeTk, digihitpos);
      // Conversion of digitised hits to the position of track parameters.
      fill_digipos_array(nsimhtTk, detidTk, simpdgidTk, simenrTk, simtimeTk, digihitpos);
      
      if (digihitpos.size()<nmnhit) continue;

      ntrkt = 1;
      Tout->Fill();

    } //end of events loop
    fileIn->cd();
    delete Tin;
    delete fileIn;
  } //end of file loop
  fileOut->cd();
  fileOut->Write();
}
////////////////////////////////////////////////////////////////////////////////////
////
////        Data point from the Geant4 hits points
////
////////////////////////////////////////////////////////////////////////////////////
void fill_digi_from_sim(int nhit, int* pdgid, float* simvx, float* simvy, float* simvz, float* simtime, vector<Hep3Vector>& hitpos) {
  for (int ij = 0;  ij<nhit; ij++) {
#ifdef DELTARAY
    //    if (abs(pdgid[ij]) !=13) continue;
    if (simtime[ij]>10) continue;
#endif    
    hitpos.push_back(Hep3Vector(simvx[ij]/1000.0, simvy[ij]/1000.0, simvz[ij]/1000.0));
  }
}

////////////////////////////////////////////////////////////////////////////////////
////
////                            Digitisation
////
////////////////////////////////////////////////////////////////////////////////////
void fill_digipos_array(int nhit, unsigned int* detid, int* pdgid, float* simenr, float* simtime, vector<Hep3Vector>& hitpos) {
  //Decode detid to position and energy and efficiency to select hitpoint for fit 
  Hep3Vector tmp3vect;
  //  cout<<"nhit "<<nhit<<endl;
  for (int ij = 0;  ij<nhit; ij++) {
    if (simenr[ij]<=0) continue;

    
#ifdef DELTARAY
    if (abs(pdgid[ij]) !=13) continue;
    if (simtime[ij]>10) continue;    
#endif    
    
    //    if (gRandom3->Uniform()>0.90) continue;
    //    int irad = ((detid[ij]>>28)&0xF);
    //    cout <<"irad "<<irad<<endl;
    //    if (irad<=6 && gRandom3->Uniform()>0.90) continue;
    
    double rho = sirad[((detid[ij]>>28)&0xF)];

    int InThe = ((detid[ij]>>15)&0x1FFF); //Decode the digitised value for z
    double zz = (0.2*(InThe+0.5) - 750.0); // Z-position in mm
#ifdef SMEARING
    zz +=gRandom3->Gaus(0.0, 0.2); //Def 0.2; Gaussian smareing of position 200 micron
#endif
    zz = (zz/1000.0); //position in m (which is used in track fit)
    
    int InPhi = (detid[ij]&0x7FFF); //Decode the digitised value value of phi;
    double phi = ((InPhi+0.5)/20000.0 - pibyfour); // convert it to rad

#ifdef SMEARING
    //    phi +=gRandom3->Gaus(0.0, 0.05); //Gaussian smareing of position 0.02mrad
    //position resolution 100micron, 50, 100, 150, 200, 300, 500, 700, 1000
    double xx = gRandom3->Gaus(0.0, 1.e-4); //5.e-4); //def 1.e-4
    phi +=xx/rho;

#endif
    tmp3vect.setRhoPhiZ(rho, phi, zz);
    cout<<"ijj "<<ij<<" "<< simenr[ij]<<" "<<rho<<" "<<phi<<" "<<zz<<endl;
    hitpos.push_back(tmp3vect); //Adding three vector in the list
  }

  //Randomly generated hit position and fill array
  // In real case, it should be indigitised form and also depend on detector condition
  // For simplicity (with endcoding and decoding of the/phi/z) directly generate the/phi/z
  for (int ij=0; ij<nNoiseHit; ij++) {
    double phi = (int((pibytwo*gRandom3->Uniform() - pibyfour)*20000+0.5))/20000.;
    double the = acos(sqrt(2)*(gRandom3->Uniform()-0.5));

    //    double xx = gRandom3->Uniform();
    //    while(xx<1./(nsilayer-1)) { // for f(r) = 1/r^2, 0 to infinty, r=r_{Minimum}/x
    //      xx = gRandom3->Uniform();
    //    }
    //    double rad = sirad[int(1./xx)]; //in metre
    double rad = sirad[int(nsilayer*gRandom3->Uniform())]; //in metre

    tmp3vect.setRhoPhiTheta(rad, phi, the);
    hitpos.push_back(tmp3vect);
  }
}

////////////////////////////////////////////////////////
//
// Simple straightline fit : Luis Lyons's book
//
///////////////////////////////////////////////////////
void straight_line_fit(vector<Hep3Vector> finder, double* par, double* parerr) {
  
  double zerr2=4.e-8;
  
  const int size = finder.size();
  double srhoz=0, srho=0, sz=0, sn=0, srho2=0;
  
  for (int ij=0; ij<size; ij++) {
    srhoz +=finder[ij].rho()*finder[ij].z()/zerr2;
    srho +=finder[ij].rho()/zerr2;
    srho2 +=finder[ij].rho()*finder[ij].rho()/zerr2;
    sz +=finder[ij].z()/zerr2;
    sn +=1/zerr2;
  }
  
  if (sn >0 && srho2*sn - srho*srho !=0) { 
    double slope = par[0] = (srhoz*sn - srho*sz)/(srho2*sn - srho*srho);
    double intersect = par[1] = sz/sn - slope*srho/sn;  // <z> = a + b <rho>
    
    double determ = (sn*srho2 - srho*srho);
    double errcst = parerr[0] = srho2/determ;
    double errcov = parerr[1] = -srho/determ;
    double errlin = parerr[2] = sn/determ;
    //    cout<<"Straight "<< slope <<" "<<intersect <<" "<<errcst<<" "<<errcov<<" "<<errlin <<endl;
  } else {
    par[0]=par[1]=parerr[0] = parerr[1] = parerr[2] = -1;
  }
}

////////////////////////////////////////////////////////////
//
// Extrapolation of tracks to new layers including the energy loos in silocon and support structure;
//
////////////////////////////////////////////////////////////

bool GetPrediction(double radin, double* Statev, double* Prediction, int il, double*  Q_k_minus, int iiter) {
  
  // First find the 3d distance using the intersection of a cylinder and a helix
  double charge = (Statev[4]>0) ? 1 : -1;
  double aftin = -charge/momconv;
  double pt0= abs(1./Statev[4]);
  double thetx =  (abs(Statev[2])>1.e-13) ? atan(1./Statev[2]) : pibytwo; // atan(1./Statev[2]);
  if (thetx<0) { thetx +=pival;}
  double ptot = pt0/sin(thetx);
  double px0= pt0*cos(Statev[3]);
  double py0= pt0*sin(Statev[3]);
  double pz0 = ptot*cos(thetx);
  double x0 = radin*cos(Statev[0]);
  double y0 = radin*sin(Statev[0]);
  double z0 = Statev[1];
  
  double aa = sirad[il]*sirad[il] - radin*radin;
  double bb = 2*aftin*(aftin*pt0*pt0 - x0*py0 + y0*px0);
  double cc = 2*aftin*(x0*px0 + y0*py0);

  double axa = bb*bb + cc*cc;
  double bxb = 2*bb*(aa-bb); // /axa; //scaled to a small number
  double cxc = ((aa-bb)*(aa-bb)-cc*cc); // /axa;
  //  axa =1;
  
  double det = bxb*bxb - 4*axa*cxc;

  if (det <0) {
    cout<<"pxx "<<charge<<" "<<aftin<<" "<<ptot<<" "<<x0<<" "<<y0<<" "<<z0<<" "<<px0<<" "<<py0<<" "<<pz0<<endl;    
    cout <<"wrong deterinant in extrapolation "<<det<<" "<<endl;
    for (int ix=0; ix<5; ix++) { Prediction[ix] = Statev[4];}
    return false;
  }
  
  double cosrs = max(-0.999999999999999, min(0.99999999999999, (-bxb + sqrt(max(1.e-50,det)))/(2*axa)));
  
  double sinrs = -charge*sqrt ( 1.0 - cosrs*cosrs);
  
  double x = x0 + aftin*(px0*sinrs - py0*(1-cosrs));
  double y = y0 + aftin*(py0*sinrs + px0*(1-cosrs));
  double ss = acos(cosrs)*ptot*abs(aftin);
  double z = z0 + ss*cos(thetx);
  double px = px0*cosrs - py0*sinrs;
  double py = py0*cosrs + px0*sinrs;
  double pz = pz0;
  // if (charge>0) {
  if (iiter==110) {
    cout<<"aaa "<< charge<<" "<<aftin<<" "<<ptot<<" "<<x0<<" "<<y0<<" "<<z0<<" "<<px0<<" "<<py0<<" "<<pz0<<endl;
    cout<<"bbb   "<< x<<" "<<y<<" "<<z<<" "<<px<<" "<<py<<" "<<pz<<" "<<cosrs<<" "<<sinrs<<" "<<ss<<endl;
  }
  
  double elos = 0.001826*(ss/(sirad[il]-radin))*(14.9+0.96*fabs(log(ptot*2.8))+0.033*ptot*(1.0-pow(ptot,-0.33)))*1e-2*1.10;

  double pscale =(ptot-elos)/ptot;
  ptot *=pscale;
  px *=pscale;
  py *=pscale;
  pz *=pscale;
  
  Prediction[0] = atan2(y,x);
  Prediction[1] = z;
  double thet = acos(pz/ptot);
  if (thet<0) { thet +=pival;}
  Prediction[2] = 1/tan(thet);
  Prediction[3] = atan2(py, px);
  Prediction[4] = charge/(ptot*sin(thet));

  return true;  
}


// c  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
// c
// c   The equations of motion are
// c
// c     Px = Px0*cos(rho*s) - Py0*sin(rho*s)
// c     Py = Py0*cos(rho*s) + Px0*sin(rho*s)
// c     Pz = Pz0
// c
// c      x = x0 + {Px0*sin(rho*s) - Py0*[1-cos(rho*s)]} / a = x0 + (Py-Py0)/a
// c      y = y0 + {Py0*sin(rho*s) + Px0*[1-cos(rho*s)]} / a = y0 - (Px-Px0)/a
// c      z = z0 + ct*s
// c
// c   where s = arc length in r-phi plane
// c         a = c_b * Bfield * q (c_b is defined in const.inc)
// c       rho = a / Pt
// c
// c   We have to find the point closest to (xc,yc,zc). The solution is
// c
// c        cos(rho*s) = (1. - rho*(dx*Py0 - dy*Px0) / Pt) / norm
// c        sin(rho*s) = (-rho*(dx*Px0 + dy*Py0) / Pt) / norm
// c
// c        norm = sqrt(1+2*rho*(dy*Px0 - dx*Py0)/Pt + rho**2*(dx**2 + dy**2))
// c          dx = x0 - xc
// c          dy = y0 - yc
// c  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
void track_move_pt_align( double* b, double* tin, double q, double* x, double* tout, double& dl) {
  double rho, delx, dely, sinps, cosps, dcosps;
  double alpha, a, ainv, sovp, ptinv, px, py;
  
  //GMA use these from database
  double c_b = 1.0;
  
  double brich = pow(b[0]*b[0]+b[1]*b[1]+b[2]*b[2],0.5);
  
  if(brich<0.00000001)brich=0.00001;
  
  double pt = pow(pow(tin[3],2.)+pow(tin[4],2.),0.5); //Correct one : s_Perp/pT = s/p )
  
  if(pt != 0.0 && q != 0.0) {
    a = -c_b * brich * q;
    ptinv = 1. / pt;
    rho = a * ptinv;
    delx = tin[0] - x[0];
    dely = tin[1] - x[1];
    ainv = 1. / a;
    px = tin[3];
    py = tin[4];
    cosps =  1. - rho*(delx*py - dely*px) * ptinv;
    sinps = -rho*(delx*px + dely*py) * ptinv;
    sovp = atan2(sinps, cosps) * ainv;
    
    alpha =  1. / sqrt(cosps*cosps + sinps*sinps);
    cosps = cosps * alpha;
    sinps = sinps * alpha;
    dcosps = 1. - cosps;
    tout[3] = px*cosps - py*sinps;
    tout[4] = py*cosps + px*sinps;
    tout[5] = tin[5];
    tout[0] = tin[0] + (px*sinps - py*dcosps) * ainv;
    tout[1] = tin[1] + (py*sinps + px*dcosps) * ainv;
    tout[2] = tin[2] + abs(sovp) * tin[5];
    dl = fabs(sovp) * pow(pow(tin[3],2.0)+pow(tin[4],2.)+pow(tin[5],2.),0.5);
  } else {
    for (int i=0; i<6; i++) {tout[i] = tin[i];}
    dl = 0.;
  }
}


